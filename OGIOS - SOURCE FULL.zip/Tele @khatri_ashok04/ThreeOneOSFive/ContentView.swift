import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color(red: 0.07, green: 0.07, blue: 0.08).edgesIgnoringSafeArea(.all)
            VStack(alignment: .leading, spacing: 15) {
                Text("Zaynix Inject")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 20)
                
                VStack(spacing: 10) {
                    HStack {
                        Text("STATUS")
                            .foregroundColor(.gray)
                        Spacer()
                        Text("VERIFIED")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color(red: 0.20, green: 0.65, blue: 0.32))
                            .cornerRadius(6)
                    }
                }
                .padding()
                .background(Color(red: 0.12, green: 0.12, blue: 0.13))
                .cornerRadius(14)
                
                let columns = [GridItem(.flexible()), GridItem(.flexible())]
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(["AimBody", "AimNeck", "AimDrag", "Magic Bullet", "AimChest", "ESP N/A"], id: \.self) { feat in
                        Text(feat)
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, minHeight: 90)
                            .background(Color(red: 0.16, green: 0.16, blue: 0.17))
                            .cornerRadius(14)
                    }
                }
                Spacer()
                Text("⚡ Inject Cheat")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(Color.white)
                    .cornerRadius(12)
                    .padding(.bottom, 20)
            }
            .padding(.horizontal, 20)
        }
    }
}
